<?php

/**
 * Plugin Name:       Checkout Product Images
 * Plugin URI:        https://azimjamshed.com/plugins/checkout-product-images
 * Description:       Display product images at the checkout page.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Azim Jamshed
 * Author URI:        https://azimjamshed.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://azimjamshed.com/plugin/update
 * Text Domain:       checkout-product-images
 * Domain Path:       /languages
 **/






// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Product Images @ Woo Checkout Page
add_filter( 'woocommerce_cart_item_name', 'wpamit_product_image_at_checkout', 9999, 3 );

function wpamit_product_image_at_checkout( $name, $cart_item, $cart_item_key ) {
    if ( ! is_checkout() ) {
        return $name;
    }

    $product = $cart_item['data'];
    $thumbnail = $product->get_image( array( '50', '50' ), array( 'class' => 'alignleft' ) );

    return $thumbnail . $name;
}


